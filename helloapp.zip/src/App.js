import { useState } from 'react';
import './app.css'

function App() {
  const [username, setUsername] = useState()

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(username);
  }

  return (<>
    <form className='p-4' onSubmit={handleSubmit}>
      <input type="text" placeholder='username'
        // onChange={(e) => handleUsernameChange(e)}
        // onChange={handleUsernameChange}
        onChange={(e) => {
          handleUsernameChange(e)
        }}
      /><br /><br />
      <input type="password" name="" id="" placeholder='enter your password' /> <br /><br />
      <input type="submit" value="submit" className='cursor-pointer' />
    </form>
  </>);
}

export default App;
